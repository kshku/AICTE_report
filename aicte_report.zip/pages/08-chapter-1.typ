#import "../theme/styles.typ": *
#import "../theme/components.typ": chapter-page, chapter-heading

#pagebreak()
#chapter-page(start: 1)[

  #chapter-heading[CHAPTER 1]

  #align(center, text(weight: "bold", size: 18pt)[INTRODUCTION])

  #v(2mm)
  #set par(justify: true)

  #h(36pt)The AICTE Activity Point Programme is an initiative that encourages students to participate in activities beyond regular classroom learning and gain practical exposure through community-based and socially relevant activities. The programme helps students connect their academic knowledge with real-world situations while developing essential skills such as communication, teamwork, problem-solving, leadership, technical awareness, and social responsibility.

  #h(36pt)As part of this programme, five activities were carried out in different areas including education, environmental awareness, food preservation, tourism promotion, and digital financial awareness. These activities provided opportunities to interact with students, local communities, businesses, and public places, thereby helping in understanding various social and practical aspects of everyday life.

  #h(36pt)The first activity focused on supporting rural students through a Summer Camp at Vivekananda College of Engineering and Technology (VCET), Puttur. Students were provided practical training in HTML, CSS, Canva, Office Tools, G-Suite, and SDGs, along with guidance on higher education, career opportunities, and future planning. They were also encouraged to participate in a hackathon, which helped develop their problem-solving, teamwork, communication, creativity, and digital skills.

  #h(36pt)The second activity was related to the Swachh Bharat Initiative and was conducted at Tannirbhavi Beach, Mangaluru. The activity involved active participation in maintaining cleanliness and creating awareness about environmental protection. Through beach cleaning and awareness activities, the importance of proper waste disposal, cleanliness of public spaces, and protection of coastal and marine environments was understood. The activity also developed a sense of civic responsibility, teamwork, and environmental awareness.

  #h(36pt)The third activity focused on facilitating 100% digitized money transactions and was carried out at Trinity General Store & Vegetables, Nehru Nagara, Puttur. Awareness was created among local shopkeepers and customers regarding digital payment methods such as UPI, QR-code payments, mobile banking, and online transactions. Basic safety practices related to digital payments were also discussed. This activity helped in understanding the importance of digital literacy, financial inclusion, and secure cashless transactions in everyday life.

  #h(36pt)These third activities provided meaningful practical exposure in different areas of society and helped in understanding the importance of education, cleanliness, sustainable practices, cultural heritage, food safety, and digital technology. They also contributed to the development of communication, teamwork, problem-solving, social awareness, and responsible citizenship. Overall, the AICTE Activity Point Programme provided an opportunity to apply knowledge in real-life situations while contributing positively to the community and environment.

  /*
  #h(36pt)The third activity focused on food preservation and packaging and provided practical exposure to food-related industrial practices. The activity was carried out at Anitha Oil Mills, Puttur, where the importance of food preservation, hygienic handling, proper storage, and suitable packaging methods was understood. Different practices used to maintain food quality, prevent spoilage, and increase shelf life were observed. This activity helped in understanding how proper food processing and packaging can reduce food wastage and ensure the safe handling of food products.
  #h(36pt)The third activity was based on tourism promotion through innovative approaches and was carried out at Shri Mahaalingeshwara Temple, Puttur. The activity focused on understanding the cultural, historical, and tourism significance of local heritage sites. Various approaches such as digital promotion, photography, social media, online information sharing, and digital navigation were considered useful for attracting visitors and creating awareness about tourist destinations. The activity also highlighted the importance of preserving cultural heritage and promoting responsible and sustainable tourism.
  */

  #set par(justify: false)
]

#pagebreak()
