#import "../../theme/styles.typ": *
#import "../../theme/components.typ": activity-title

#activity-title(centered: true)[Food Preservation and Packaging]

#v(4mm)
#set par(justify: true)

#text(weight: "bold", size: 16pt)[2.9 Overview]

#h(36pt)This activity was conducted as part of the AICTE Activity Point Programme with the objective of creating awareness about traditional and modern methods of food preservation and the importance of proper food packaging. The activity, titled "Food Preservation and Packaging," was carried out at Anitha Oil Mills, Puttur, and was successfully completed as part of the requirements for the Bachelor of Engineering programme.

#h(36pt)The activity provided practical exposure to the various methods used to preserve food products and increase their shelf life. Students gained an understanding of the importance of proper storage, handling, preservation, and packaging in maintaining the quality and safety of food products.

#h(36pt)Different aspects of food preservation, such as protecting food from moisture, air, microorganisms, contamination, and spoilage, were discussed. The importance of maintaining suitable storage conditions and following hygienic practices during food processing and handling was also highlighted.

#h(36pt)The activity also focused on the role of packaging in protecting food products during storage, transportation, and distribution. Students learned how appropriate packaging materials can help maintain product quality, prevent contamination, extend shelf life, and reduce food wastage.

#h(36pt)Overall, the activity provided valuable practical knowledge about food preservation and packaging practices and helped students understand their importance in food safety, quality maintenance, and reduction of food wastage.

#text(weight: "bold", size: 16pt)[2.10 Use of Technology]

- Observation of modern food processing and preservation techniques used in the industry.
- Understanding the use of appropriate packaging materials and methods for food products.
- Exposure to equipment and processes involved in food handling and packaging.
- Use of technology to improve food quality, shelf life, and storage.
- Awareness of hygienic and systematic methods used during food processing and packaging.

#text(weight: "bold", size: 16pt)[2.11 Sustainable Development Best Practices]

- Promoting responsible food preservation and storage practices.
- Reducing food wastage by increasing the shelf life of food products.
- Encouraging proper packaging to protect food from contamination and spoilage.
- Promoting hygienic and safe food-handling practices.
- Encouraging efficient use of food resources and reducing unnecessary wastage.
- Supporting SDG 2 – Zero Hunger by reducing food loss and improving food availability.
- Supporting SDG 12 – Responsible Consumption and Production through efficient food utilization and sustainable practices.

#text(weight: "bold", size: 16pt)[2.12 Outcome of the Activity]

#h(36pt)The activity provided practical knowledge about food preservation, packaging, storage, hygiene, and food safety. Students gained an understanding of how proper preservation and packaging can increase shelf life, maintain food quality, and minimize food wastage. The programme also created awareness about responsible consumption and sustainable food-management practices.

#set par(justify: false)
